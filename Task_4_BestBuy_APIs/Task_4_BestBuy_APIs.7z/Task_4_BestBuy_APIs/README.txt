- This is a sample test cases for best buy APIs. Tests could be repeated for each end point but here I am shuffling tests over end points, however it should be the same for most of end points. 
- All test cases are placed under 'tests' folder
- You will need to do "pip install" in terminal for needed packages under 'tests' folder path and below are the packages needed:
  - pytest
  - requests
  - json
  - jsonpath
  - os
ex: pip install requests
- Run test cases using pytest command "pytest -s -v " in the console in correct path for folder tests

