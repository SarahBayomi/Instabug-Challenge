- This is a sample test cases for best buy APIs. Tests should be repeated for each end point but here I am shuffling tests over end points, however it should be the same for most of end points. 
- All test cases are placed under tests folder
- All will need to do "pip install" for needed packages under write path of the folder:
  - pytest
  - Requests
  - json
  - jsonpath
  - os
- Run test cases using pytest command "pytest -s -v " in the console in correct path for folder tests

