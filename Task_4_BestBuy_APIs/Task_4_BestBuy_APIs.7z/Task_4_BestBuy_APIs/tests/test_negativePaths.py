import os
import requests
import json
import jsonpath

# API URL
url = 'http://localhost:3030'

# 1) Create a resource with already existed id
def create_existed_id():
    category = url + '/categories'
    # Read input json file
    file = open(os.getcwd() + "\\createCategory.json", 'r')
    json_input = file.read()
    request_json = json.loads(json_input)
    # POST category with id same to existing one
    response = requests.post(category, request_json)
    assert response.status_code == 400
    response_get_json = response.json()
    errors = jsonpath.jsonpath(response_get_json, 'errors')
    errors_message = jsonpath.jsonpath(errors[0][0], 'message')
    assert errors_message[0] == 'id must be unique'

# 2) Delete a service that doesn't exist
def delete_not_existed():
    service = url + '/services'
    id = 23
    service = service + '/' + str(id)
    response = requests.delete(service)
    response_get_json = response.json()
    message = jsonpath.jsonpath(response_get_json, 'message')
    assert response.status_code == 404
    assert message[0] == "No record found for id '" + str(id) + "'"

# 3) Update category to already existed one
def update_already_existed():
    category = url + '/categories'
    # Read input json file
    file = open(os.getcwd() + "\\updateCategory.json", 'r')
    json_input = file.read()
    request_json = json.loads(json_input)
    # Update category with id same to existing one
    response = requests.get(category)
    assert response.status_code == 200
    response = requests.put(category, request_json)
    # It is already existed as get request above passed but the message is:"No record found for id 'null
    assert response.status_code == 400
    response_get_json = response.json()
    errors = jsonpath.jsonpath(response_get_json, 'errors')
    errors_message = jsonpath.jsonpath(errors[0][0], 'message')
    assert errors_message[0] == 'id must be unique'

# 4) Searching for invalid product
def invalid_search():
    product = url + '/products/309403483'
    id = 309403483
    response = requests.get(product)
    assert response.status_code == 404
    response_get_json = response.json()
    message = jsonpath.jsonpath(response_get_json, 'message')
    assert message[0] == "No record found for id '" + str(id) + "'"

# 5) Missing required parameters for adding new store
def missing_paramater():
    store = url + '/stores'
    # Read input json file
    file = open(os.getcwd() + "\\missing_parameter_store.json", 'r')
    json_input = file.read()
    request_json = json.loads(json_input)
    # POST store with missing city and state parameters
    response = requests.post(store, request_json)
    assert response.status_code == 400
    response_get_json = response.json()
    errors = jsonpath.jsonpath(response_get_json, 'errors')
    missing_city = errors[0][0]
    assert missing_city == "should have required property 'city'"
    missing_state = errors[0][1]
    assert missing_state == "should have required property 'state'"